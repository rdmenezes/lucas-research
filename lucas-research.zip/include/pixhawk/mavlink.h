/** @file
 *	@brief MAVLink comm protocol.
 *	@see http://pixhawk.ethz.ch/software/mavlink
 *	 Generated on Sunday, September 11 2011, 13:52 UTC
 */
#ifndef MAVLINK_H
#define MAVLINK_H

#include "pixhawk.h"

#endif
